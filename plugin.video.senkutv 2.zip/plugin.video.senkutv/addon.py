import xbmc
import xbmcgui
import xbmcplugin
import requests
import sys
import json
import urllib.parse

# Identificador del plugin
ADDON_HANDLE = int(sys.argv[1])

# URL de la lista JSON de eventos
EVENTOS_JSON_URL = "https://raw.githubusercontent.com/Tbleo1189/Senku-Tv/refs/heads/main/eventos.json"
# URL de la lista M3U remota
M3U_REMOTE_URL = "https://raw.githubusercontent.com/Tbleo1189/Senku-Tv/refs/heads/main/lista1.m3u"

def cargar_lista_eventos_json(url_json):
    """Carga y parsea una lista de eventos JSON."""
    eventos = []
    try:
        xbmc.log(f"Intentando cargar eventos desde: {url_json}", xbmc.LOGINFO)
        
        # Intentamos obtener el JSON de la URL remota
        response = requests.get(url_json, timeout=10)
        response.raise_for_status()  # Verifica si hubo algún error en la petición

        # Procesamos los datos JSON
        eventos_json = response.json()

        # Verificamos la estructura de los datos
        xbmc.log(f"Datos JSON recibidos: {json.dumps(eventos_json, indent=2)}", xbmc.LOGINFO)

        # Parseamos cada evento y los agregamos a la lista
        for evento in eventos_json:
            if "name" in evento and "acestream_id" in evento and "start_time" in evento:
                eventos.append({
                    "name": evento["name"],
                    "acestream_id": evento["acestream_id"],
                    "start_time": evento["start_time"],
                    "description": evento.get("description", "")
                })

        # Verificamos si la lista de eventos está vacía
        if not eventos:
            xbmc.log("No se encontraron eventos válidos en el JSON", xbmc.LOGERROR)

    except requests.exceptions.RequestException as e:
        xbmc.log(f"Error al cargar los eventos desde la URL: {e}", xbmc.LOGERROR)
    except json.JSONDecodeError as e:
        xbmc.log(f"Error al decodificar el JSON: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Error inesperado al procesar los eventos: {e}", xbmc.LOGERROR)

    return eventos

def cargar_lista_m3u_remota(url_m3u):
    """Carga y parsea una lista M3U remota."""
    canales = []
    try:
        xbmc.log(f"Cargando lista M3U remota desde: {url_m3u}", xbmc.LOGINFO)
        
        # Intentamos obtener el archivo M3U desde la URL remota
        response = requests.get(url_m3u, timeout=10)
        response.raise_for_status()  # Verifica si hubo algún error en la petición

        # Procesamos el contenido del archivo M3U
        contenido_m3u = response.text

        # Parseamos cada canal en el archivo M3U
        nombre_canal = None
        for linea in contenido_m3u.splitlines():
            if linea.startswith("#EXTINF"):
                nombre_canal = linea.split(",")[-1].strip()
            elif linea.startswith("acestream://"):
                acestream_id = linea.split("acestream://")[-1].strip()
                if nombre_canal:
                    canales.append({"name": nombre_canal, "id": acestream_id})
                    nombre_canal = None  # Restablecer para el siguiente canal

        # Verificamos si la lista de canales está vacía
        if not canales:
            xbmc.log("No se encontraron canales válidos en el M3U", xbmc.LOGERROR)

    except requests.exceptions.RequestException as e:
        xbmc.log(f"Error al cargar la lista M3U desde la URL: {e}", xbmc.LOGERROR)
    except Exception as e:
        xbmc.log(f"Error inesperado al procesar el M3U: {e}", xbmc.LOGERROR)

    return canales

def play_acestream_link(acestream_id):
    """Reproduce un enlace AceStream utilizando Horus."""
    encoded_id = urllib.parse.quote_plus(acestream_id)  # Codificamos el ID de AceStream
    # Ejecutamos el comando para reproducir el stream con Horus
    command = f'RunPlugin(plugin://script.module.horus/?action=play&id={encoded_id})'
    xbmc.executebuiltin(command)  # Ejecutamos el comando para Kodi

def asociar_canales_a_eventos(eventos, canales):
    """Asocia los canales con los eventos basados en el `acestream_id`."""
    # Creamos un diccionario para hacer la búsqueda rápida de los canales por su ID
    canales_dict = {canal['id']: canal for canal in canales}

    # Asociamos el canal a cada evento
    for evento in eventos:
        acestream_id = evento['acestream_id']
        if acestream_id in canales_dict:
            evento['canal'] = canales_dict[acestream_id]
        else:
            evento['canal'] = None  # Si no hay canal asociado, lo dejamos como None

    return eventos

def list_events():
    """Muestra los eventos con sus canales asociados desde el archivo JSON."""
    eventos = cargar_lista_eventos_json(EVENTOS_JSON_URL)
    canales = cargar_lista_m3u_remota(M3U_REMOTE_URL)

    # Asociamos los canales a los eventos
    eventos = asociar_canales_a_eventos(eventos, canales)

    if eventos:
        xbmc.log("Eventos y canales cargados correctamente", xbmc.LOGINFO)

        # Mostrar los eventos con su canal correspondiente
        for evento in eventos:
            nombre_evento = evento.get("name", "Evento sin nombre")
            start_time = evento.get("start_time", "Hora no disponible")
            description = evento.get('description', 'Descripción no disponible')

            # Si la fecha ya está en el formato deseado, solo mostrarla
            fecha_formateada = start_time  # Ya está en el formato deseado

            # Información del canal asociado al evento
            canal = evento.get('canal', None)
            if canal:
                nombre_canal = canal['name']
            else:
                nombre_canal = "Canal no disponible"

            # Crear el ListItem para el evento
            list_item = xbmcgui.ListItem(label=f"{nombre_evento} ({start_time}) - Canal: {nombre_canal}")
            list_item.setInfo('video', {
                'title': nombre_evento,
                'plot': description,
                'premiered': start_time
            })

            # Si el evento tiene canal asociado, lo reproducimos
            if canal:
                url = f"{sys.argv[0]}?action=play_acestream&id={canal['id']}"
            else:
                url = ""  # Si no hay canal asociado, no creamos la URL de reproducción

            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)

        xbmcplugin.endOfDirectory(ADDON_HANDLE)
    else:
        xbmcgui.Dialog().notification("Error", "No se pudieron cargar los eventos", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("No se pudieron cargar los eventos", xbmc.LOGERROR)

def list_m3u_channels():
    """Muestra los canales cargados desde la lista M3U remota."""
    canales = cargar_lista_m3u_remota(M3U_REMOTE_URL)

    if canales:
        xbmc.log("Canales M3U cargados correctamente", xbmc.LOGINFO)
        
        # Crear un menú de canales en Kodi
        for canal in canales:
            list_item = xbmcgui.ListItem(label=canal['name'])
            list_item.setInfo('video', {'title': canal['name']})

            url = f"{sys.argv[0]}?action=play_acestream&id={canal['id']}"
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)

        xbmcplugin.endOfDirectory(ADDON_HANDLE)
    else:
        xbmcgui.Dialog().notification("Error", "No se pudieron cargar los canales M3U", xbmcgui.NOTIFICATION_ERROR)
        xbmc.log("No se pudieron cargar los canales M3U", xbmc.LOGERROR)

def mostrar_menus_principales():
    """Muestra el menú principal con opciones."""
    xbmc.log("Mostrando menú principal", xbmc.LOGINFO)
    
    # Opción para ver eventos
    url_events = f"{sys.argv[0]}?action=list_events"
    list_item = xbmcgui.ListItem(label="Ver Directos")
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url_events, listitem=list_item, isFolder=True)
    
    # Opción para ver canales M3U
    url_channels = f"{sys.argv[0]}?action=list_m3u_channels"
    list_item = xbmcgui.ListItem(label="Ver Canales Actualizados")
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url_channels, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

if __name__ == "__main__":
    # Obtener los parámetros de la URL
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    action = params.get("action", [None])[0]

    if action == "list_events":
        list_events()
    elif action == "list_m3u_channels":
        list_m3u_channels()
    elif action == "play_acestream":
        # Reproducir el evento o canal con AceStream
        acestream_id = params.get("id", [None])[0]
        if acestream_id:
            play_acestream_link(acestream_id)
        else:
            xbmcgui.Dialog().notification("Error", "No se proporcionó un ID de AceStream", xbmcgui.NOTIFICATION_ERROR)
    else:
        mostrar_menus_principales()
